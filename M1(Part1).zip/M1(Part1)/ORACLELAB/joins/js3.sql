SELECT s.student_code,s.student_name,bt.book_code,b.book_name from student_master s ,book_transactions bt,book_master b  WHERE  s.student_code=bt.student_code AND bt.book_code=b.book_code  AND Book_expected_return_date=sysdate;



