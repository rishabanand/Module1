SELECT s.staff_code,s.staff_name,d.dept_name,ds.design_name from 
  staff_master s join department_master d on d.dept_code=s.dept_code join 
designation_master ds on ds.design_code=s.design_code AND  
MONTHS_BETWEEN(sysdate,to_date(s.hiredate,'DD-MON-YY'))<=3;