SELECT s.staff_code,s.Staff_Name,d.dept_name,e.staff_name from staff_master s join department_master d on d.dept_code=s.dept_code join staff_master e on s.mgr_code=e.staff_code ; 


	Select s.staff_code,s.staff_name,s.dept_code,m.staff_name  from staff_master s 
	 join staff_master m on s.staff_code = m.staff_code and s.staff_code = 7369;
	