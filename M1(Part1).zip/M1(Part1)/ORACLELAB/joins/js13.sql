SELECT s.dept_code,d.dept_name,count(*) from staff_master s join department_master d on s.dept_code=d.dept_code 
 group by s.dept_code,d.dept_name;