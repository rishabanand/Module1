SELECT t.*,b.* from book_master b join book_transactions t  
 on b.book_code=t.book_code where book_actual_return_date IS NULL 
 AND  
 to_date(book_expected_return_date,'DD-MON-YY')=to_date(NEXt_DAY(sysdate-7,'monday'),'DD-MON-YY');